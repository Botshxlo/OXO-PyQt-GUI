# OXO-PyQt-GUI

# use 
# $ pip install qstylizer 
# on the command line
# to install the qstylizer package
